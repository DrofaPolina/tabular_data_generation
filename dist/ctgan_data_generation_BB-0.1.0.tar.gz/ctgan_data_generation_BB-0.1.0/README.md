Library for extending tabular datasets based on CTGAN model

## Installation

! pip install ctgan

! pip install -i https://test.pypi.org/simple/ tabular-data-generation-0==0.1.0



