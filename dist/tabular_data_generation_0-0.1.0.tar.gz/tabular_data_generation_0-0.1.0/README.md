! pip install ctgan

! pip install -i https://test.pypi.org/simple/ tabular-data-generation==0.1.0 



